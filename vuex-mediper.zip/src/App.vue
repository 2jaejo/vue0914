<template>
  <div>
    
      <Navi></Navi>

  </div>
</template>

<script>

import Navi from './components/Navigator.vue'


export default {
  components:{
    Navi,

  },
  computed:{

  }
}
</script>